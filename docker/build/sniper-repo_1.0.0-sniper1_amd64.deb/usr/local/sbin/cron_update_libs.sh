#!/bin/bash

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games

echo -e "[`date`] new run"
echo -e ""
apt-get -y update 
unattended-upgrade --apt-debug -d 
apt-get -y autoremove

echo -e "[`date`] finish"
echo -e ""

